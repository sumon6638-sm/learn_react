# Fitness House Club

This project is live on netlify [Fitness House](https://fitnesshouse-club-fahad.netlify.app/).

## Project Summary

This Project is about a academy which give various service regarding fitness , provides more then 200 international Certficate to prove your skill to reputed gym center. 

### Project Functionality

1. In the Service Section you will find some course you can enroll and get certified.
2. In The blog section you will get some tips and trick accorading to some people observation.
3. You can Read the article of blog section.

### Project Fetures
1. Will add another page will be shop
2. In the Shop People can by healthy Supplement and other things which is helpfull.