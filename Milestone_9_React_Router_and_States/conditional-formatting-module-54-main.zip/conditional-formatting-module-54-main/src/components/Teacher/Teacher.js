import React from 'react';

const Teacher = () => {
    return (
        <div>
            <h4>A Teacher</h4>
        </div>
    );
};

export default Teacher;