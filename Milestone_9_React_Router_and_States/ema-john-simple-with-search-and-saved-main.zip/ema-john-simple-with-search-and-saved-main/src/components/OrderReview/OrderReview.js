import React from 'react';

const OrderReview = () => {
    return (
        <div>
            <h2>This is Order Review</h2>
        </div>
    );
};

export default OrderReview;