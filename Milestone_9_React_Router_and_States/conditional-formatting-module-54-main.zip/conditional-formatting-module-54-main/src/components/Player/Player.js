import React from 'react';

const Player = () => {
    return (
        <div>
            <h4>A Player</h4>
        </div>
    );
};

export default Player;