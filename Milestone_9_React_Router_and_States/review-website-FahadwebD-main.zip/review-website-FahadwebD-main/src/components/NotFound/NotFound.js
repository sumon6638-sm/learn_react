import React from 'react';

const NotFound = () => {
    return (
        <div style={{ marginTop:200 , marginBottom:150}}>
            <h2 >404 Check URL</h2>
        </div>
    );
};

export default NotFound;