import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <p className="bg-yellow-200 text-4xl hover:text-blue-900">This is my text</p>
      <p className="text-primary">hello my text</p>
      <p className="text-custom">This is my own tailwind class</p>
    </div>
  );
}

export default App;
