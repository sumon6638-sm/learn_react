# Welcome to "MEDICAL PLANET"

## Medical Planet [Live Site Link](https://medical-planet-sumon6638.web.app/)

## [Repository Link](https://github.com/Programming-Hero-Web-Course3/healthcare-related-website-sumon6638-sm)

### Benefits of this Website:
    1. This is an medical treatment and hospitality based website.
    2. From here one can know about the treatment and doctor easily.
    3. By this website one can get contact with the hospital by virtually.
    4. By this website the medical administrator can collect data of patient or user.
    5. From this website one can know about the cost about doctor appointment, medical treatment and service.